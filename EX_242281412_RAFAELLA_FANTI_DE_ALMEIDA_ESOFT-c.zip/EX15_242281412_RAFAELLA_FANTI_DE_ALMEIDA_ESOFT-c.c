#include <stdio.h>

int main() {
    char senha[256];
    int i;
    int temMaiuscula = 0, temMinuscula = 0, temNumero = 0, temEspecial = 0;
    int valido = 1;

    printf("Digite a senha: ");
    fgets(senha, sizeof(senha), stdin);

    for (i = 0; senha[i] != '\0'; i++) {
        if (senha[i] >= 'A' && senha[i] <= 'Z') {
            temMaiuscula = 1;
        } else if (senha[i] >= 'a' && senha[i] <= 'z') {
            temMinuscula = 1;
        } else if (senha[i] >= '0' && senha[i] <= '9') {
            temNumero = 1;
        } else if (senha[i] == '!' || senha[i] == '@' || senha[i] == '#' || senha[i] == '$' || senha[i] == '%' || senha[i] == '^' || senha[i] == '&' || senha[i] == '*' || senha[i] == '(' || senha[i] == ')' || senha[i] == '-' || senha[i] == '+' || senha[i] == '=' || senha[i] == '[' || senha[i] == ']' || senha[i] == '{' || senha[i] == '}' || senha[i] == '|' || senha[i] == ';' || senha[i] == ':' || senha[i] == '\'' || senha[i] == '"' || senha[i] == ',' || senha[i] == '.' || senha[i] == '/' || senha[i] == '<' || senha[i] == '>' || senha[i] == '?' || senha[i] == '~' || senha[i] == '`') {
            temEspecial = 1;
        }
    }

    if (i < 9) {
        valido = 0;
    } else if (!temMaiuscula || !temMinuscula || !temNumero || !temEspecial) {
        valido = 0;
    }

    if (valido) {
        printf("Senha v�lida.\n");
    } else {
        printf("Senha inv�lida.\n");
    }

    return 0;
}

