#include <stdio.h>

int main(){
	float salario;
	char avaliacao;
	
	printf("Digite o seu salario: ");
	scanf("%f", &salario);
	
	printf("Digite a avalia�ao: ");
	scanf("%s", &avaliacao);
	
	switch(avaliacao){
	
	     case 'a' :
	       salario = (salario* 0.15) + salario;
	       printf("Seu bonus eh de %f ", salario);
	       break;
	     
	    case 'b'  :
			salario = (salario* 0.10) + salario;
			printf("Seu bonus eh de %f ", salario);
			break;
			
		case 'c' :
			salario = (salario* 0.05) + salario;
			printf("Seu bonus eh de %f ", salario);
			break;
			
		default :
		  printf("Nao ha desconto ");
		  break;
		  
   }
	return 0;
}
