#include <stdio.h>


float calcularPrecoTotal(int codigoProduto, int quantidade) {
    float precoUnitario;
    float desconto;
    float precoTotal;

    
    switch (codigoProduto) {
        case 1: 
            precoUnitario = 10.0;
            desconto = 0.1; 
            break;
        case 2:
            precoUnitario = 20.0;
            desconto = 0.2; 
            break;
        case 3: 
            precoUnitario = 30.0;
            desconto = 0.15; 
            break;
        default:
            printf("C�digo de produto inv�lido.\n");
            return 0.0;
    }

    
    precoTotal = precoUnitario * quantidade * (1 - desconto);
    return precoTotal;
}

int main() {
    int codigoProduto, quantidade;
    float precoTotal;

    
    printf("Digite o c�digo do produto (1 para Produto A, 2 para Produto B, 3 para Produto C): ");
    scanf("%d", &codigoProduto);

    printf("Digite a quantidade: ");
    scanf("%d", &quantidade);

    if (quantidade <= 0) {
        printf("Quantidade inv�lida.\n");
        return 1;
    }

    
    precoTotal = calcularPrecoTotal(codigoProduto, quantidade);

    
    if (precoTotal > 0.0) {
        printf("O pre�o total da compra �: R$ %.2f\n", precoTotal);
    }

    return 0;
}

