#include <stdio.h>

int main() {
    float taxaBase, taxaPorKm, quilometrosRodados, valorTotal;

    printf("Digite a taxa base do aluguel: ");
    scanf("%f", &taxaBase);

    printf("Digite a taxa adicional por quil�metro rodado: ");
    scanf("%f", &taxaPorKm);

    printf("Digite a quantidade de quil�metros rodados: ");
    scanf("%f", &quilometrosRodados);

    valorTotal = taxaBase + (taxaPorKm * quilometrosRodados);

    printf("O valor total do aluguel �: R$ %.2f\n", valorTotal);

    return 0;
}

