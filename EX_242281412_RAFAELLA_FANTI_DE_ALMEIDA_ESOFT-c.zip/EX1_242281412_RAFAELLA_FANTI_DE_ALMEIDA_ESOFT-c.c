#include <stdio.h>

int main(){
	
	float valor;
	
	printf("Digite o valor para saber o desconto: ");
	scanf("%f", &valor);
	
	if(valor >= 100 && valor <= 500){
		printf("O desconto eh de: %f", valor*0.10);
		printf("\nO valor total a pagar eh: %f", ( valor - (valor*0.10)));
	} else if(valor > 500){
		printf("O desconto eh de: %f", valor*0.20);
		printf("\nO valor total a pagar eh: %f", ( valor - (valor*0.20)));
	}else{
		printf("Nao ha desconto: ");
	}
	
	
	
	return 0;
}
