#include <stdio.h>

int main() {
    float a, b, c;

    printf("Digite o comprimento do primeiro lado: ");
    scanf("%f", &a);

    printf("Digite o comprimento do segundo lado: ");
    scanf("%f", &b);

    printf("Digite o comprimento do terceiro lado: ");
    scanf("%f", &c);

    if ((a <= 0 || b <= 0 || c <= 0) || (a + b <= c || a + c <= b || b + c <= a)) {
        printf("Valores inv�lidos para um tri�ngulo.\n");
    } else if (a == b && b == c) {
        printf("O tri�ngulo � equil�tero.\n");
    } else if (a == b || b == c || a == c) {
        printf("O tri�ngulo � is�sceles.\n");
    } else {
        printf("O tri�ngulo � escaleno.\n");
    }

    return 0;
}

