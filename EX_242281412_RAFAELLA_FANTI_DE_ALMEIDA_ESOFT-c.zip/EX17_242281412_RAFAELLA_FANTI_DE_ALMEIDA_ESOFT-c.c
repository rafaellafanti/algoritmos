#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    char codigo[256];
    int valido = 1;

    printf("Digite o c�digo da encomenda: ");
    fgets(codigo, sizeof(codigo), stdin);

    codigo[strcspn(codigo, "\n")] = 0;

    int comprimento = strlen(codigo);

    if (comprimento != 8) {
        valido = 0;
    } else if (codigo[0] == '0') {
        valido = 0;
    } else {
        for (int i = 0; i < comprimento; i++) {
            if (!isdigit(codigo[i])) {
                valido = 0;
                break;
            }
        }
    }

    if (valido) {
        printf("C�digo v�lido.\n");
    } else {
        printf("C�digo inv�lido.\n");
    }

    return 0;
}

