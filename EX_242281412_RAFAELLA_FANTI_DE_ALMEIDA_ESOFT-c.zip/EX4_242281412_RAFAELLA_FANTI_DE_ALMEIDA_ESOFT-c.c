#include <stdio.h>
#include <math.h>

int main() {
    int num;
    int raiz;

    printf("Digite um numero: ");
    scanf("%d", &num);

    if (num < 0) {
        printf("%d nao eh um quadrado perfeito.\n", num);
    }

    raiz = (int)sqrt(num); 

    if (raiz * raiz == num) {
        printf("%d eh um quadrado perfeito.\n", num);
    } else {
        printf("%d nao eh um quadrado perfeito.\n", num);
    }

    return 0;
}
