#include <stdio.h>

int main() {
    int numAlunos, i;
    float nota, somaNotas = 0.0, media;

    printf("Digite o n�mero de alunos: ");
    scanf("%d", &numAlunos);

    if (numAlunos <= 0) {
        printf("N�mero de alunos inv�lido.\n");
        return 1;
    }

    for (i = 0; i < numAlunos; i++) {
        printf("Digite a nota do aluno %d: ", i + 1);
        scanf("%f", &nota);

        if (nota < 0 || nota > 10) {
            printf("Nota inv�lida. Digite uma nota entre 0 e 10.\n");
            i--;
            continue;
        }

        somaNotas += nota;
    }

    media = somaNotas / numAlunos;

    if (media >= 7.0) {
        printf("A turma est� aprovada.\n");
    } else if (media >= 5.0) {
        printf("A turma est� em recupera��o.\n");
    } else {
        printf("A turma est� reprovada.\n");
    }

    return 0;
}

