#include <stdio.h>

int main() {
    int tipoPacote, numeroPessoas;
    float precoBase, desconto, precoTotal;

    printf("Escolha o tipo de pacote:\n");
    printf("1. Pacote B�sico\n");
    printf("2. Pacote Intermedi�rio\n");
    printf("3. Pacote Premium\n");
    printf("Digite o n�mero do pacote escolhido: ");
    scanf("%d", &tipoPacote);

    switch (tipoPacote) {
        case 1:
            precoBase = 100.0;
            break;
        case 2:
            precoBase = 200.0;
            break;
        case 3:
            precoBase = 300.0;
            break;
        default:
            printf("Pacote inv�lido.\n");
            return 1;
    }

    printf("Digite o n�mero de pessoas: ");
    scanf("%d", &numeroPessoas);

    if (numeroPessoas > 10) {
        desconto = 0.10;
    } else if (numeroPessoas >= 6) {
        desconto = 0.05;
    } else {
        desconto = 0.0;
    }

    precoTotal = precoBase * numeroPessoas * (1 - desconto);

    printf("O custo total do pacote �: R$ %.2f\n", precoTotal);

    return 0;
}

