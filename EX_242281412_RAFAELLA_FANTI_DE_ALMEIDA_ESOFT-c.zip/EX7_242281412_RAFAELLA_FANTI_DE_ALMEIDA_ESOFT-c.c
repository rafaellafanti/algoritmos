#include <stdio.h>
#include <string.h> 

int main() {
   
    const char usuarioCorreto[] = "usuario123";
    const char senhaCorreta[] = "senha123";

   
    char usuarioEntrada[50];
    char senhaEntrada[50];

    
    printf("Digite o nome de usu�rio: ");
    scanf("%49s", usuarioEntrada); 

    printf("Digite a senha: ");
    scanf("%49s", senhaEntrada); 

    
    if (strcmp(usuarioEntrada, usuarioCorreto) == 0 && strcmp(senhaEntrada, senhaCorreta) == 0) {
        printf("Acesso concedido.\n");
    } else {
        printf("Acesso negado.\n");
    }

    return 0;
}

