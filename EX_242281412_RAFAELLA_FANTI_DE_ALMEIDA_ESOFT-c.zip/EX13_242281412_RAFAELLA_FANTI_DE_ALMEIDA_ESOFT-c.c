#include <stdio.h>

int main() {
    int pontos;

    printf("Digite a quantidade de pontos ganhos: ");
    scanf("%d", &pontos);

    if (pontos < 0) {
        printf("N�mero de pontos inv�lido.\n");
    } else if (pontos >= 1000) {
        printf("N�vel de premia��o: Ouro\n");
    } else if (pontos >= 500) {
        printf("N�vel de premia��o: Prata\n");
    } else if (pontos >= 100) {
        printf("N�vel de premia��o: Bronze\n");
    } else {
        printf("Nenhum pr�mio\n");
    }

    return 0;
}

