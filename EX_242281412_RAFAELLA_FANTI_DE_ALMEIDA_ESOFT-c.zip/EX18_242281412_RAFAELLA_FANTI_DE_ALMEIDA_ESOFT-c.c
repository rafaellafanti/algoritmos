#include <stdio.h>

int main() {
    float principal, taxaJuros, montante;
    int periodos, anos;
    float taxaPeriodica;

    printf("Digite o valor do principal (investimento inicial): ");
    scanf("%f", &principal);

    printf("Digite a taxa de juros anual (em porcentagem): ");
    scanf("%f", &taxaJuros);

    printf("Digite o n�mero de per�odos de capitaliza��o por ano: ");
    scanf("%d", &periodos);

    printf("Digite o n�mero de anos: ");
    scanf("%d", &anos);

   
    taxaJuros = taxaJuros / 100.0;

    taxaPeriodica = taxaJuros / periodos;

    montante = principal;
    for (int i = 0; i < periodos * anos; i++) {
        montante *= (1 + taxaPeriodica);
    }

    printf("O montante acumulado ap�s %d anos �: R$ %.2f\n", anos, montante);

    return 0;
}

