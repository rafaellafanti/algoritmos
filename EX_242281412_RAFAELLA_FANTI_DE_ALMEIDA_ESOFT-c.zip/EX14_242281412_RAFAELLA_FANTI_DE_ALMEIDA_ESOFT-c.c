#include <stdio.h>

int main() {
    int quantidade, categoria;
    float precoUnitario, precoTotal, desconto;

    printf("Digite o pre�o unit�rio do livro: ");
    scanf("%f", &precoUnitario);

    printf("Digite a quantidade de livros: ");
    scanf("%d", &quantidade);

    printf("Digite a categoria do livro (1 para Ficc�o, 2 para N�o-Fic��o, 3 para Infantil): ");
    scanf("%d", &categoria);

    if (quantidade > 10) {
        desconto = 0.10;
    } else if (quantidade >= 5) {
        desconto = 0.05;
    } else {
        desconto = 0.0;
    }

    if (categoria == 1) {
        desconto += 0.05;
    } else if (categoria == 2) {
        desconto += 0.03;
    } else if (categoria == 3) {
        desconto += 0.02;
    }

    precoTotal = precoUnitario * quantidade * (1 - desconto);

    printf("O pre�o total da compra �: R$ %.2f\n", precoTotal);

    return 0;
}

