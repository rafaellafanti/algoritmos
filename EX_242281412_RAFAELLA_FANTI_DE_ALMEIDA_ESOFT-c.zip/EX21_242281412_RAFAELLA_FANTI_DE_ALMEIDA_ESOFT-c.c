#include <stdio.h>
#include <math.h>

int main() {
    float valorEmprestimo, taxaJurosAnual, taxaJurosMensal, valorPrestacao;
    int numeroParcelas;

    printf("Digite o valor do empr�stimo: ");
    scanf("%f", &valorEmprestimo);

    printf("Digite a taxa de juros anual (em porcentagem): ");
    scanf("%f", &taxaJurosAnual);

    printf("Digite o n�mero total de parcelas: ");
    scanf("%d", &numeroParcelas);
   
    taxaJurosAnual = taxaJurosAnual / 100.0;
    taxaJurosMensal = taxaJurosAnual / 12.0;
   
    if (taxaJurosMensal == 0) {
        valorPrestacao = valorEmprestimo / numeroParcelas;
    } else {
        valorPrestacao = (valorEmprestimo * taxaJurosMensal) / (1 - pow(1 + taxaJurosMensal, -numeroParcelas));
    }

    printf("O valor da presta��o mensal �: R$ %.2f\n", valorPrestacao);

    return 0;
}

