#include <stdio.h>

int main() {
    int escolha;
    float temperatura, resultado;

    printf("Escolha a convers�o:\n");
    printf("1. Celsius para Fahrenheit\n");
    printf("2. Fahrenheit para Celsius\n");
    printf("Digite sua escolha (1 ou 2): ");
    scanf("%d", &escolha);

    if (escolha == 1) {
        printf("Digite a temperatura em Celsius: ");
        scanf("%f", &temperatura);
        resultado = (temperatura * 9 / 5) + 32;
        printf("%.2f Celsius � igual a %.2f Fahrenheit.\n", temperatura, resultado);
    } else if (escolha == 2) {
        printf("Digite a temperatura em Fahrenheit: ");
        scanf("%f", &temperatura);
        resultado = (temperatura - 32) * 5 / 9;
        printf("%.2f Fahrenheit � igual a %.2f Celsius.\n", temperatura, resultado);
    } else {
        printf("Escolha inv�lida.\n");
    }

    return 0;
}

