#include <stdio.h>

int main(){
	
	int numero, compnumero, tentativas;
	
	compnumero = 10;
	tentativas = 9;
	
	while (tentativas > 0) {
        printf("Escolha um n�mero entre 1 e 100: ");
        scanf("%d", &numero);

        if (numero < 1 || numero > 100) {
            printf("N�mero inv�lido. Tente novamente.\n");
            continue; 
        }
   }
	if(numero > compnumero){
		    printf("O numero eh menor ");
	    	}else if(numero == compnumero){
	    		printf("Parabens voce acertou! ");
			}
			 else{
				printf("O numero eh maior ");
			}


		tentativas--;
		
		
	switch(tentativas){
		case 9 :
			printf("Voce tem mais nove tentativas ");
			break;
		case 8 :
			printf("Voce tem mais oito tentativas ");
			break;
		case 7 :
			printf("Voce tem mais sete tentativas ");
			break;
		case 6 :
			printf("Voce tem mais seis tentativas ");
			break;
		case 5 :
			printf("Voce tem mais cinco tentativas ");
			break;
		case 4 :
			printf("Voce tem mais quatro tentativas ");
			break;
		case 3 :
			printf("Voce tem mais tres tentativas ");
			break;
		case 2 :
			printf("Voce tem mais duas tentativas ");
			break;
		case 1 :
			printf("Voce tem mais uma tentativa ");
			break;	
			
	}
	
	if (tentativas == 0 && numero != compnumero) {
        printf("Voc� n�o conseguiu adivinhar o n�mero. O n�mero era %d.\n", compnumero);
    }
	
	return 0;
}
