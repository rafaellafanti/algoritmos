#include <stdio.h>

int main() {
    float distancia;
    float consumoMedio;
    float precoCombustivel;
    float custoTotal;

    printf("Digite a dist�ncia percorrida (em km): ");
    scanf("%f", &distancia);

    printf("Digite o consumo m�dio de combust�vel (em litros por km): ");
    scanf("%f", &consumoMedio);

    printf("Digite o pre�o do combust�vel (em reais por litro): ");
    scanf("%f", &precoCombustivel);

    custoTotal = distancia * consumoMedio * precoCombustivel;

    printf("O custo total da viagem �: R$ %.2f\n", custoTotal);

    return 0;
}

