#include <stdio.h>

int main() {
    float temperatura, umidade, sensacaoTermica;

    printf("Digite a temperatura em graus Celsius: ");
    scanf("%f", &temperatura);

    printf("Digite a umidade relativa em porcentagem: ");
    scanf("%f", &umidade);

    sensacaoTermica = temperatura + (0.33 * umidade) - (0.70 * temperatura) - 4.00;

    printf("A sensa��o t�rmica �: %.2f graus Celsius\n", sensacaoTermica);

    return 0;
}

