#include <stdio.h>

int main(){
	
	int valor, nota100, nota50, nota20, nota10, nota5, resto;
	
	
	printf("Digite o valor: ");
	scanf("%d", &valor);
	
	nota100 = valor/ 100;
	resto = valor % 100;
	
	nota50 = resto / 50;
	resto = resto % 50;
	
	nota20 = resto / 20;
	resto = resto % 20;
	
	nota10 = resto / 10;
	resto = resto % 10;
	
	nota5 = resto / 5;
	resto = resto % 5;
	
	printf("Notas de 100:  %d\n", nota100);  
	printf("Notas de 50:   %d\n", nota50); 
	printf("Notas de 20:   %d\n", nota20); 
	printf("Notas de 10:   %d\n", nota10); 
	printf("Notas de 5:    %d\n", nota5); 
	
	if(resto < 0){
		printf("Valor n�o compativel ");
	}
	
	return 0;
}
